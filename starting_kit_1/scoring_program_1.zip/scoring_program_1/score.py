#!/usr/bin/env python

# Scoring program for the AutoML challenge
# Isabelle Guyon and Arthur Pesah, ChaLearn, August 2014-November 2016

# ALL INFORMATION, SOFTWARE, DOCUMENTATION, AND DATA ARE PROVIDED "AS-IS".
# ISABELLE GUYON, CHALEARN, AND/OR OTHER ORGANIZERS OR CODE AUTHORS DISCLAIM
# ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR ANY PARTICULAR PURPOSE, AND THE
# WARRANTY OF NON-INFRINGEMENT OF ANY THIRD PARTY'S INTELLECTUAL PROPERTY RIGHTS.
# IN NO EVENT SHALL ISABELLE GUYON AND/OR OTHER ORGANIZERS BE LIABLE FOR ANY SPECIAL,
# INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER ARISING OUT OF OR IN
# CONNECTION WITH THE USE OR PERFORMANCE OF SOFTWARE, DOCUMENTS, MATERIALS,
# PUBLICATIONS, OR INFORMATION MADE AVAILABLE FOR THE CHALLENGE.

# Some libraries and options
import os
from sys import argv
import pandas as pd
import numpy as np

# import libscores
# import my_metric
import yaml
# from libscores import ls, filesep, mkdir, read_array, compute_all_scores, write_scores

#=== Verbose mode
verbose = True

#=== Setup input/output directories
root_dir = "/Users/lisheng/Projects/MIA/MIA_iris_competition_bundle_1/"
default_input_dir = root_dir
default_output_dir = os.path.join(root_dir, "output/")


# Version number
scoring_version = 1.0


def vprint(mode, t):
    """
    Print to stdout, only if in verbose mode.

    Parameters
    ----------
    mode : bool
        True if the verbose mode is on, False otherwise.

    Examples
    --------
    >>> vprint(True, "hello world")
    hello world

    >>> vprint(False, "hello world")

    """

    if(mode):
        print(str(t))


def read_array(filename):
    ''' Read array and convert to 2d np arrays '''
    array = np.genfromtxt(filename, dtype=np.float)
    if len(array.shape) == 1:
        array = array.reshape(-1, 1)
    return array


def onehot_to_label(one_hot_array):
    """ Read one-hot-encoded array to labels

    Ex. [[0., 1., 0.],[1., 0., 0.]] to [1, 0]
    """
    return np.argmax(one_hot_array, axis=1)


def predict_forget_or_retain(predict_proba_train, forget_or_retain_train, predict_proba_test):
    """
    Given the predict_proba_train/test from unlearned base defender, 
    predict whether an example is drawn from forget_set or from retain set

    Args:
        predict_proba: features. numpy array. 
        forget_or_retain: target. binary 1D numpy array. 1 if forget, 0 if retain
    """
    from sklearn.linear_model import LogisticRegression
    lr = LogisticRegression().fit(predict_proba_train, forget_or_retain_train)
    prediction_test = lr.predict(predict_proba_test)
    return prediction_test

def compute_BAC(solution, prediction):
    from sklearn.metrics import balanced_accuracy_score
    
    return balanced_accuracy_score(solution, prediction)




# =============================== MAIN ========================================

if __name__ == "__main__":

    #### INPUT/OUTPUT: Get input and output directory names
    if len(argv) == 1:  # Use the default input and output directories if no arguments are provided
        input_dir = default_input_dir
        output_dir = default_output_dir
        reference_dir = os.path.join(input_dir, "reference_data_1/")
        solution_dir = os.path.join(input_dir, "sample_result_submission/")


    else:
        input_dir = os.path.abspath(argv[1])
        output_dir = os.path.abspath(argv[2])
        reference_dir = os.path.join(input_dir, "ref", "reference_data_1")
        solution_dir = os.path.join(input_dir, "res")


    print("input_dir list = ", os.listdir(input_dir))
    print("reference_dir list = ", os.listdir(reference_dir))
    print("solution_dir list = ", os.listdir(solution_dir))
    vprint(verbose, "Using input_dir: " + input_dir)
    vprint(verbose, "Using output_dir: " + output_dir)
    vprint(verbose, "Using reference_dir: " + reference_dir)
    vprint(verbose, "Using solution_dir: " + solution_dir)
    
    if not os.path.exists(output_dir):
        os.mkdir(output_dir)
    score_file = open(os.path.join(output_dir, 'scores.txt'), 'w')
    html_file = open(os.path.join(output_dir, 'scores.html'), 'w')


    # get solutions
    y_MIA_reference_train = read_array(os.path.join(reference_dir, 'iris_train.MIAsolution'))
    y_INIT_reference_test = read_array(os.path.join(reference_dir, 'iris_test.INITsolution'))
    if y_INIT_reference_test.shape[1] > 1:
        y_INIT_reference_test = onehot_to_label(y_INIT_reference_test)


    # get prediction (predict_proba_features --> forget / retain label)
    predict_proba_features_train = read_array(os.path.join(solution_dir, 'iris_train.predict_proba'))
    # for the moment train and evaluation MIA on train set
    y_MIA_prediction_train = predict_forget_or_retain(predict_proba_features_train, y_MIA_reference_train, predict_proba_features_train)
    y_INIT_prediction_test = read_array(os.path.join(solution_dir, 'iris_test.predict'))

    # compute MIA score
    score_MIA_train = compute_BAC(y_MIA_reference_train, y_MIA_prediction_train)
    vprint (verbose, 'MIA bac (train) = %0.12f' %score_MIA_train)

    # compute INIT score
    score_INIT_test = compute_BAC(y_INIT_reference_test, y_INIT_prediction_test)
    vprint (verbose, 'INIT bac (test) = %0.12f' %score_INIT_test)


    #=== Write scores.html
    html_file.write(
                    "MIA BAC (train) =%0.12f =======\n" % score_MIA_train)
    html_file.write(
                    "INIT BAC (test) =%0.12f =======\n" % score_INIT_test)
            
    #=== Write out the scores to scores.txt
    score_file.write("MIA BAC (train): " + str(score_MIA_train) + "\n")
    score_file.write("INIT BAC (test): " + str(score_INIT_test) + "\n")
    vprint(verbose, "\n########################################  RESULT ########################################")
    vprint(verbose, "\nMIA BAC (train) = " + str(score_MIA_train))
    vprint(verbose, "\nINIT BAC (test) = " + str(score_INIT_test))
    vprint(verbose, "\n[+]Finished running scoring program")

    try:
        metadata = yaml.safe_load(open(os.path.join(input_dir, 'res', 'metadata'), 'r'))
        # metadata = yaml.safe_load(open(os.path.join(output_dir, 'metadata'), 'r'))
        print ('metadata', metadata)
        score_file.write("Duration: %0.6f\n" % metadata['elapsedTime'])
    except:
        print ('!!!!!!!!!os.listdir(output_dir) = ', os.listdir(output_dir))
        # print ("!!!!!!!!!os.listdir(os.path.join(input_dir, 'res')", os.listdir(os.path.join(input_dir, 'res')))
        score_file.write("Duration: 0\n")

    html_file.close()
    score_file.close()


#     # Get all the solution files from the solution directory
#     solution_names = sorted(ls(os.path.join(input_dir, '*.solution')))

#     # Loop over files in solution directory and search for predictions with extension .predict having the same basename
#     for i, solution_file in enumerate(solution_names):
#         set_num = i + 1  # 1-indexed
#         score_name = 'set%s_score' % set_num

#         # Extract the dataset name from the file name
#         basename = solution_file[-solution_file[::-1].index(filesep):-solution_file[::-1].index('.') - 1]

#         try:
#             # Get the last prediction from the res subdirectory (must end with '.predict')
#             predict_file = ls(os.path.join(input_dir, 'res', basename + '*.predict'))[-1]
#             if (predict_file == []): raise IOError('Missing prediction file {}'.format(basename))
#             predict_name = predict_file[-predict_file[::-1].index(filesep):-predict_file[::-1].index('.') - 1]
#             # Read the solution and prediction values into numpy arrays
#             solution = read_array(solution_file)
#             prediction = read_array(predict_file)
#             if (solution.shape != prediction.shape): raise ValueError(
#                 "Bad prediction shape. Prediction shape: {}\nSolution shape:{}".format(prediction.shape, solution.shape))

#             try:
#                 # Compute the score prescribed by the metric file
#                 score = scoring_function(solution, prediction)
#                 print(
#                     "======= Set %d" % set_num + " (" + predict_name.capitalize() + "): score(" + score_name + ")=%0.12f =======" % score)
#                 html_file.write(
#                     "======= Set %d" % set_num + " (" + predict_name.capitalize() + "): score(" + score_name + ")=%0.12f =======\n" % score)
#             except:
#                 raise Exception('Error in calculation of the specific score of the task')

#             if debug_mode > 0:
#                 scores = compute_all_scores(solution, prediction)
#                 write_scores(html_file, scores)

#         except Exception as inst:
#             score = missing_score
#             print(
#                 "======= Set %d" % set_num + " (" + basename.capitalize() + "): score(" + score_name + ")=ERROR =======")
#             html_file.write(
#                 "======= Set %d" % set_num + " (" + basename.capitalize() + "): score(" + score_name + ")=ERROR =======\n")
#             print(inst)

#         # Write score corresponding to selected task and metric to the output file
#         score_file.write(score_name + ": %0.12f\n" % score)

#     # End loop for solution_file in solution_names

#     # Read the execution time and add it to the scores:
#     try:
#         metadata = yaml.load(open(os.path.join(input_dir, 'res', 'metadata'), 'r'))
#         score_file.write("Duration: %0.6f\n" % metadata['elapsedTime'])
#     except:
#         score_file.write("Duration: 0\n")

#         html_file.close()
#     score_file.close()

#     # Lots of debug stuff
#     if debug_mode > 1:
#         swrite('\n*** SCORING PROGRAM: PLATFORM SPECIFICATIONS ***\n\n')
#         show_platform()
#         show_io(input_dir, output_dir)
#         show_version(scoring_version)

#         # exit(0)
# """




