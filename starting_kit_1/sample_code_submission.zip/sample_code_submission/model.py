'''
Sample predictive model.
You must supply at least 5 methods:
- unlearn: unlearns the model with forget set.
- predict: uses the model to perform predictions.
- predict_proba: uses the model to perform proba predictions.
- save: saves the model.
- load: reloads the model.
'''
import pickle
import numpy as np   # We recommend to use numpy arrays
from os.path import isfile
import copy


class model:
    def __init__(self, base_defender):
        '''
        Should initialize with a trained base_defender, provided in starting_kit
        Args:
            base_defender: a trained sklearn estimator implementing a partial_fit() function
        '''
        # self.base_defender = base_defender
        self.unlearned_defender = copy.deepcopy(base_defender)
        self.is_unlearned = False

    def unlearn(self, X_forget, y_forget, X_retain, y_retain, num_epochs=1):
        '''
        This function should unlearn the base_defender with the forget and/or retain set (X_forget, y_forget, X_retain, y_retain).
        Here we do nothing in this example...
        Args:
            X_forget: numpy arrays. Forget data.
            y_forget: numpy arrays. Forget labels.
            X_retain: numpy arrays. Forget data.
            y_retain: numpy arrays. Forget labels.
            classes: list of all possible class labels, including those in forget set and retain set. 
            num_epochs: int. Number of epoch to run for unlearning.
        For classification, labels could be either numbers 0, 1, ... c-1 for c classe
        
        '''
        # collect all possible class labels
        classes_ = list(set(y_forget) | set(y_retain))
        # unlearning via finetuning with retain set
        for epoch in range(num_epochs):
            print('UNLEARN Epoch {}/{}'.format(epoch, num_epochs - 1))
            self.unlearned_defender.partial_fit(X_retain, y_retain, classes_)
        self.is_unlearned=True

    def predict(self, X):
        '''
        This function should provide predictions of labels on (test) data.
        Here I use the predict function from the unlearned estimator.
        '''
        if self.is_unlearned:
            y = self.unlearned_defender.predict(X)
        else:
            from sklearn.exceptions import NotFittedError
            return NotFittedError("Model should be unlearned to make predictions.")
        return y


    def predict_proba(self, X):
        '''
        This function should provide probabilities of prediction of labels on (test) data.
        Here I use the predict_proba function from the unlearned estimator.
        '''
        if self.is_unlearned:
            y = self.unlearned_defender.predict_proba(X)
        else:
            from sklearn.exceptions import NotFittedError
            return NotFittedError("Model should be unlearned to make predictions.")
        return y


    def save(self, path="./"):
        '''
        Save a trained model.
        '''
        with open(path, 'wb') as f:
            pickle.dump(self, f, pickle.HIGHEST_PROTOCOL)
        

    def load(self, path="./"):
        '''
        Load a trained model.
        '''
        return self
